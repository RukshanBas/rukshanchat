import { Component, OnInit, Input } from '@angular/core';
import { Router} from '@angular/router';

@Component({
  selector: 'app-chat-row',
  templateUrl: './chat-row.component.html',
  styleUrls: ['./chat-row.component.scss'],
})
export class ChatRowComponent implements OnInit {

  constructor(private router:Router) { }

  @Input() senderID:string = ""
  @Input() senderName:string = ""
  @Input() avatarURL:string = ""

  ngOnInit() {}
  toSingleChat(event:any,senderID:string){
    this.router.navigate(['toSingleChat/'+senderID]);
  }

}
