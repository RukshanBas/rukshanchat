import { Component,OnInit,ViewChild, ViewContainerRef, ComponentFactoryResolver } from '@angular/core';
import { ChatRowComponent } from './chat-row/chat-row.component';
import {HttpClient} from '@angular/common/http';
import {map, filter, catchError, mergeMap} from 'rxjs/operators';
import { MenuBarComponent } from '../menu-bar/menu-bar.component';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  entryComponents: [ChatRowComponent, MenuBarComponent]
})
export class Tab1Page {

  myUserID:string = "";
  constructor(private httpObj: HttpClient, private cfr: ComponentFactoryResolver) {}
  @ViewChild('chatRows',{static: true,read: ViewContainerRef}) forChatRow: ViewContainerRef;
  ngOnInit(){
    this.myUserID = localStorage.getItem("UserID");
    let innerThis=this;
    this.httpObj.get('http://rukshanMobileApp.artsuit.ca/index.php/Chats/listChatsForUser?userID='+this.myUserID).pipe(map((res:any)=>{return res;})).subscribe(data => {
    console.log(data);
    //chatMessage: "Hello Gajen"
    //id: "1"
    //receiverID: "2"
    //receiverName: "Gajen"
    //senderID: "1"
    //senderName: "rukshan"
    //sentTime: "2021-06-06 11:56:32"
    
    data.forEach((element:any)=>{
    const factory = innerThis.cfr.resolveComponentFactory(ChatRowComponent);
        const componentRef = innerThis.forChatRow.createComponent(factory);
        componentRef.instance.senderID=element.senderID;
        if (innerThis.myUserID == element.senderID) {
          componentRef.instance.senderName=element.recieverName;
          componentRef.instance.avatarURL="http://rukshanmobileapp.artsuit.ca/"+element.receiverAvatarURL;
        }
        else {
          componentRef.instance.senderName=element.senderName;
          componentRef.instance.avatarURL="http://rukshanmobileapp.artsuit.ca/"+element.senderAvatarURL;

        }
        
       
    });



});
  

}
}

