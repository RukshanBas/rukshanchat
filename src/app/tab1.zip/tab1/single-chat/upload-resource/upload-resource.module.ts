import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UploadResourceComponent } from './upload-resource.component'


@NgModule({
  declarations: [ UploadResourceComponent ],
  imports: [
    CommonModule
  ]
})
export class UploadResourceModule { }
