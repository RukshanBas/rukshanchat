import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { SingleChatPageRoutingModule } from './single-chat-routing.module';
import { SingleChatPage } from './single-chat.page';
import { ChatTextModule } from './chat-text/chat-text.module';
import { ChatAttachmentModule } from './chat-attachment/chat-attachment.module';
import { MenuBarModule } from '../../menu-bar/menu-bar.module';
import { UploadResourceModule } from './upload-resource/upload-resource.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SingleChatPageRoutingModule,
    MenuBarModule,
    ChatTextModule,
    ChatAttachmentModule,
    UploadResourceModule
  ],
  declarations: [SingleChatPage]
})
export class SingleChatPageModule {}
