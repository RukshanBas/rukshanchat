import { Component,OnInit,ViewChild, ViewContainerRef, ComponentFactoryResolver } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ActivatedRoute} from '@angular/router';
import {map, filter, catchError, mergeMap} from 'rxjs/operators';
import { ChatTextComponent } from './chat-text/chat-text.component';
import { ChatAttachmentComponent } from './chat-attachment/chat-attachment.component';
import { MenuBarComponent } from '../../menu-bar/menu-bar.component';
import { ModalController } from '@ionic/angular';
import { UploadResourceComponent } from './upload-resource/upload-resource.component';

@Component({
  selector: 'app-single-chat',
  templateUrl: './single-chat.page.html',
  styleUrls: ['./single-chat.page.scss'],
  entryComponents: [ChatTextComponent, ChatAttachmentComponent, MenuBarComponent]
})
export class SingleChatPage implements OnInit {
private forRoute:any;
  textInput:string=""
  myUserID:string=""
  opponentID:string=""
  modal: any
  constructor(private route: ActivatedRoute, private httpObj:HttpClient, private cfr: ComponentFactoryResolver, private mc: ModalController) { }
  @ViewChild('allChats',{static: true,read: ViewContainerRef}) singleChat: ViewContainerRef;


  ngOnInit() {
    this.myUserID = localStorage.getItem("UserID");
    var innerThis = this;
    this.forRoute = this.route.params.subscribe(params => {
      innerThis.opponentID = params['userID'];
      innerThis.singleChat.clear();
      innerThis.httpObj.get('http://rukshanmobileapp.artsuit.ca/index.php/Chats/getChatsBetween?userIDToServer='+innerThis.myUserID+'&opponentIDToServer='+innerThis.opponentID).pipe(map((res:any)=>{return res;})).subscribe(data => {
        if (data != null) {
          data.forEach((element:any) => {
            if (element.resourceURL!=null) {
              const factory = innerThis.cfr.resolveComponentFactory(ChatAttachmentComponent);
              const componentRef = innerThis.singleChat.createComponent(factory);
              componentRef.instance.chatMessage=element.chatMessage;
              componentRef.instance.attachementURL="http://rukshanmobileapp.artsuit.ca/"+element.resourceURL;
              
              console.log(element.resourceURL);
              if(element.senderID==innerThis.myUserID){
              componentRef.instance.position="right";
              }
              else{
              componentRef.instance.position="left";
              }
            }
            else {
              const factory = innerThis.cfr.resolveComponentFactory(ChatTextComponent);
              const componentRef = innerThis.singleChat.createComponent(factory);
              componentRef.instance.chatMessage=element.chatMessage;
            
              if(element.senderID==innerThis.myUserID){
              componentRef.instance.position="right";
              componentRef.instance.buttonColor="success";
              }
              else{
              componentRef.instance.position="left";
              componentRef.instance.buttonColor="primary";
              }
            }


          });
        
        } else {
          
        }
      });
    });
  }
  sendChat(event:any,chatText:string) {
    var innerThis = this;
    let formData=new FormData();
    formData.append("myUserID",this.myUserID);
    formData.append("opponentID",this.opponentID);
    formData.append("chatMessage",this.textInput);
    this.httpObj.post<FormData>('http://rukshanmobileapp.artsuit.ca/index.php/Chats/feedChat',formData).subscribe(data => {
     innerThis.textInput = "";
     innerThis.ngOnInit(); 
  });
}
async presentModal() {
  this.modal = await this.mc.create({
    component: UploadResourceComponent,
    cssClass: 'my-custom-class'
  });
  return await this.modal.present();
}

}

//senderID
//recieverID
//chatMessage
//sentTime