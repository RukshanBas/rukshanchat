import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-chat-attachment',
  templateUrl: './chat-attachment.component.html',
  styleUrls: ['./chat-attachment.component.scss'],
})
export class ChatAttachmentComponent implements OnInit {
  @Input() chatMessage: string=""
  @Input() position: string=""
  @Input() attachementURL: string=""


  constructor() { }

  ngOnInit() {}

}
